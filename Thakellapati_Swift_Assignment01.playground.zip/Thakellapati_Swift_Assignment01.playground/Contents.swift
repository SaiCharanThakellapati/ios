import UIKit
//*******Questions******//
// 1. How to declare an empty variable of String type?
//Ans: Explicitly declaring a variable "a" of type string.

var a : String
print("----------------------")

// End of question 1

/*===================================================================================================================================================*/

//2. Declare 2 variables holding 20 and 20.5 respectively and caluclute their sum and displayed result should be of type double.
//Ans : Declaring 2 variables "x & y" & assining values to it.
var x = 20
var y = 20.5
/*Calculating the sum of 2 variables "x & y".
Typecasting "x" to convert the int x into double x,
hence we can do the sum of same data type else we get type error for sum of diff data type.*/
var sum = Double(x) + y
print(sum)
print("----------------------")

// End of question 2

/*===================================================================================================================================================*/

// 3. Calculate the area(rounded to 2 decimal points) of a rhombus with diagonal values as 25 and 26.8 respectively. Print the result obtained as "The area of the rhombus with given diagonal values is *****", replace the **** with the area. [Area = Diagonal_1*Diagonal_2]/2
//Ans : Declaring 2 variables "Diagonal_1 & Diagonal_2" & assigning values to it.
var Diagonal_1 = 25
var Diagonal_2 = 26.8
/*Calculating the area of 2 variables "Diagonal_1 & Diagonal_2" of a rhombus.
Typecasting "Diagonal_1" to convert the int Diagonal_1 into double Diagonal_1,
hence we can do the area of same data type else we get type error for sum of diff data type.
Now since the value of the Area has a decimal points we are rounding off the value.*/
var Area = round((Double(Diagonal_1) * Diagonal_2)/2)
print("The area of the rhombus with given diagonal values is \(Area)")
print("----------------------")
// End of question 3

/*===================================================================================================================================================*/

// 4. Using 3 print statements write something about you in 3 sentences, one for each print but print first 2 statements in single line and next statement in the 2nd line.
//Ans : Using the terminotor we can terminate the console & print the 2nd line after the 1st line.
//since we are using the teminator the cursor dos not go to the next line (i.e; \n is not used after the 1st line).
print("Hello all my name is Sai Charan Thakellapati." , terminator : " " )
print("I like to play games.")
print("I am from Hyderabad!")
print("----------------------")
// End of question 4

/*===================================================================================================================================================*/

// 5. Using one print statement display the following 3M
// "Swift is a powerful and intuitive programming language for iOS, iPadOS, macOS, tvOS, and watchOS.
//   Writing Swift code is interactive and fun, the syntax is concise yet expressive, and Swift includes modern features   developers love.
//   Swift code is safe by design and produces software that runs lightning-fast."
//Ans : Using ("""  """) we can print the paragraphs & by using the return (i.e; "\r") we can move the paragraph into the nextline.
print("""
      Swift is a powerful and intuitive programming language for iOS, iPadOS, macOS, tvOS, and watchOS.\rWriting Swift code is interactive and fun,the syntax is concise yet expressive, and Swift includes modern features   developers love.\rSwift code is safe by design and produces software that runs lightning-fast.
      """)
print("----------------------")
// End of question 5

/*===================================================================================================================================================*/

// 6. Print a Multiplication table of any number of your choice starting from 1 to 10
//Ans : Using for loop and taking a range from 1 to 10, we are multiplying the number with the range ang iterating it each time.
var num = 3
for i in 1...10 {
print("\(num) * \(i) = \(num*i)")
}
print("----------------------")
// End of question 6

/*===================================================================================================================================================*/

// 7. Calculate the area and perimeter of a square with side = 8 , and if the area and perimeter is more than 20 display a message stating that "The area of the given square is ***** and perimeter is *****" else display "Area and perimeter is less than 20"[NOTE : replace stars with area and perimeter respectively.]
var side = 8
var area = side * side
var parimeter = 4 * side
//using if else condition to check the Area and perimeter.
if area > 20 && parimeter > 20 {
    print("The area of the given square is \(area) and perimeter is \(parimeter).")
}
else {
    print("Area and perimeter is less than 20")
}
print("----------------------")
// End of question 7

/*===================================================================================================================================================*/
