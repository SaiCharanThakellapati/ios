//
//  ViewController.swift
//  Calculator
//
//  Created by Thakellapati,Sai Charan on 2/2/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var Display: UILabel!
//Declare & initalize to some default values.
    var operand1 : Double = -1.1
    var operator1 : Character = " "
    var operand2 : Double = -1.1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func five(_ sender: UIButton) {
        Display.text! = Display.text!+"5"
        if operand1 == -1.1{
            operand1 = 5
        }else{
            operand2 = 5
        }
    }
    
    @IBAction func plus(_ sender: UIButton) {
        Display.text! = Display.text!+"+"
        if operator1 == " "{
            operator1 = "+"
        }
    }
    
    @IBAction func three(_ sender: UIButton) {
        Display.text! = Display.text!+"3"
        if operand2 == -1.1{
            operand2 = 3
        }else{
            operand1 = 3
        }
    }
    
    @IBAction func equal(_ sender: UIButton) {
        Display.text! = Display.text!+"="
        if(operator1 == "+"){
            Display.text! =  Display.text!+"\(operand1+operand2)"
        }
        
    }
    
}

